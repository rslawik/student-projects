#!/usr/bin/env python
from distutils.core import setup
setup(name="master-slave", version="1.0", py_modules=['master', 'slave'])